﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Практика14_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter a1 = File.CreateText("file.txt");
            bool a = true;
            int c = 0, c1 = 0;
            Stack<char> pr = new Stack<char>();
            try
            {
                if (textBox1.Text != "")
                {
                    
                        string text = textBox1.Text;
                        for (int i = 0; i < text.Length; i++)
                        {
                            pr.Push(text[i]);
                            if (pr.Peek() != '0' && pr.Peek() != '1' && pr.Peek() != '2' && pr.Peek() != '3' &&
                                pr.Peek() != '4' && pr.Peek() != '5' && pr.Peek() != '6' && pr.Peek() != '7' &&
                                pr.Peek() != '8' && pr.Peek() != '9' && pr.Peek() != '*' && pr.Peek() != '/' &&
                                pr.Peek() != '+' && pr.Peek() != '-' && pr.Peek() != '.' && pr.Peek() != ')' &&
                                pr.Peek() != '(')
                                a = false;
                            if (pr.Peek() == ')') c++;
                            if (pr.Peek() == '(') c1++;
                        }
                        if (a == true && c == c1)
                        {
                            listBox1.Items.Add($"В выражениии {textBox1.Text} скобки сбалансированы");
                            a1.WriteLine(text);
                            a1.Close();
                        }
                        else if (c > c1)
                        {
                            listBox1.Items.Add($"В выражениии {textBox1.Text} скобки не сбалансированы");
                            listBox1.Items.Add($"возможно лишняя ) скобка на позиции: {text.IndexOf('(')}");
                            StreamWriter a2 = new StreamWriter("file1.txt");
                            a2.WriteLine('('+ textBox1.Text);
                            a2.Close();
                        }
                        else if (c < c1)
                        {
                            listBox1.Items.Add($"В выражениии {textBox1.Text} скобки не сбалансированы");
                            listBox1.Items.Add($"возможно лишняя ( скобка на позиции: {text.IndexOf(')')}");
                            StreamWriter a3 = new StreamWriter("file1.txt");
                            a3.WriteLine(textBox1.Text + ')');
                            a3.Close();
                        }
                }
                else
                    MessageBox.Show("Вы не ввели выражение");
            }
            catch (FormatException) 
            { 
                MessageBox.Show("Введите корректно"); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Queue<int> a = new Queue<int>();
            listBox2.Items.Clear();
            if (textBox2.Text != "")
            {
                int n = Convert.ToInt32(textBox2.Text);
                for (int i = 1; i <= n; i++)
                {
                        a.Enqueue(i);
                }
                if (a.Count > 0)
                {
                    listBox2.Items.Add($"n:{textBox2.Text}");
                    listBox2.Items.Add($"Размерность очереди {a.Count}");
                    a.Clear();
                    listBox2.Items.Add($"Новая размерность очереди:{a.Count}");
                }
                else MessageBox.Show("очередь пустая");

            }
            else MessageBox.Show("заполните пустое поле");
            
        }
    }
}
