﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_14_3
{
    internal class People
    {
        private string name;
        private string surname;
        private string patronymic;
        private int voz;
        private double ves;
        public People(string name, string surname, string patronymic, int voz, double ves)
        {
            this.name = name;
            this.surname = surname;
            this.patronymic = patronymic;
            this.voz = voz;
            this.ves = ves;
        }
        public People(string name, string surname, string patronymic)
        {
            this.name = name;
            this.surname = surname;
            this.patronymic = patronymic;
        }
        public People(int voz, double ves)
        {
            this.voz = voz;
            this.ves = ves;
        }
        public void Set_Name(string name)
        {
            this.name = name;
        }
        public string Get_Name()
        {
            return name;
        }
        public void Set_Surname(string surname)
        {
            this.surname = surname;
        }
        public string Get_Surname()
        {
            return surname;
        }
        public void Set_Patronymic(string patronymic)
        {
            this.patronymic = patronymic;
        }
        public string Get_Patronymic()
        {
            return patronymic;
        }
        public void Set_Voz(int voz)
        {
            this.voz = voz;
        }
        public int Get_Voz()
        {
            return voz;
        }
        public void Set_Ves(double ves)
        {
            this.ves = ves;
        }
        public double Get_Ves()
        {
            return ves;
        }
    }
}
