﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Практика_14_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Queue<People> people = new Queue<People>();
            string file = "file2.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("файл не найден");
            }
            else
            {
                string[] a = File.ReadAllLines(file);

                People p1 = new People("", "", "", 0, 0.0);

                foreach (string b in a)
                {
                    string[] p2 = b.Split(' ');
                    string name = p2[0];
                    p1.Set_Name(name);
                    string surname = p2[1];
                    p1.Set_Surname(surname);
                    string patronymic = p2[2];
                    p1.Set_Patronymic(patronymic);
                    int voz = Convert.ToInt32(p2[3]);
                    p1.Set_Voz(voz);
                    double ves = Convert.ToDouble(p2[4]);
                    p1.Set_Ves(ves);
                    listBox1.Items.Add($"{p1.Get_Name()} {p1.Get_Surname()} {p1.Get_Patronymic()} {p1.Get_Voz()} {p1.Get_Ves()}");
                    people.Enqueue(new People(name, surname, patronymic, voz, ves));
                }
                var peo = from p in people
                where Convert.ToInt32(p.Get_Voz()) < 40
                select p;
                foreach (var a1 in peo)
                {
                    listBox2.Items.Add($"Имя: {a1.Get_Name()} \nФамилия: {a1.Get_Surname()} \nОтчество: {a1.Get_Patronymic()} Возраст: {a1.Get_Voz()} Вес: {a1.Get_Ves()} ");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Queue<People> people1 = new Queue<People>();
            string file4 = "file4.txt";
            string file5 = "file5.txt";
            if (!File.Exists(file4) && !File.Exists(file5))
            {
                MessageBox.Show("файл не найден");
            }
            else
            {
                string[] a1 = File.ReadAllLines(file4);
                People p1 = new People("", "", "");
                foreach (string b in a1)
                {
                    string[] p6 = b.Split(' ');
                    string name = p6[0];
                    p1.Set_Name(name);
                    string surname = p6[1];
                    p1.Set_Surname(surname);
                    string patronymic = p6[2];
                    p1.Set_Patronymic(patronymic);
                    listBox4.Items.Add($"{p1.Get_Name()} {p1.Get_Surname()} {p1.Get_Patronymic()}");
                    people1.Enqueue(new People(name, surname, patronymic));
                    listBox3.Items.Add($"{p1.Get_Name()} {p1.Get_Surname()} {p1.Get_Patronymic()}");
                    listBox3.Sorted = (true);

                }
                string[] a2 = File.ReadAllLines(file5);
                People p2= new People(0,0.0);
                foreach (string b1 in a2)
                {
                    string[] p3 = b1.Split(' ');
                    int voz = Convert.ToInt32(p3[0]);
                    p2.Set_Voz(voz);
                    double ves = Convert.ToDouble(p3[1]);
                    p2.Set_Ves(ves);
                    listBox4.Items.Add($"Возраст: {p2.Get_Voz()} Вес: {p2.Get_Ves()}");
                    people1.Enqueue(new People(voz, ves));
                }
                
            }
        }
        
    }
}
