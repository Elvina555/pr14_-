﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_14._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            Stack<int> a = new Stack<int>();
            listBox1.Items.Add($"Размерность стека: {n}");
            listBox1.Items.Add($"Верхний элемент стэка: {n}");
            for (int i=1;i<=n;i++)
            {
                a.Push(i);
            }
            listBox1.Items.Add($"Размерность стека: {a.Count}");
            listBox1.Items.Add("Содержимое стека:");
            for(int i = 1; i <= n; i++)
            {
                int b = a.Pop();
                listBox1.Items.Add(b);
            }
            listBox1.Items.Add($"Новая размерность стэка:{a.Count}");
        }
    }
}
